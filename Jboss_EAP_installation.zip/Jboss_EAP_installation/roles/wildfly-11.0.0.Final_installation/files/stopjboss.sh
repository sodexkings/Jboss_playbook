#!/bin/bash
kill -9 `pgrep -f /opt/wildfly`

