#!/bin/bash
cd /opt/jboss-eap-7.1/bin/
./standalone.sh > /opt/wildfly-11.0.0.Final/logs/standalone.log &
