#!/bin/bash
cd /opt/jboss-eap-7.1/bin/
./standalone.sh > /opt/jboss-eap-7.1/logs/standalone.log &
