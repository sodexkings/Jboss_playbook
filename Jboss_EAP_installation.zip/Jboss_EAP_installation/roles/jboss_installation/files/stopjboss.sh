#!/bin/bash
kill -9 `pgrep -f /opt/jboss-eap-7.1`

