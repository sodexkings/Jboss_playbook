#!/bin/bash
kill -9 `pgrep -f /opt/jvm2/jboss-eap-7.1`

