#!/bin/bash
cd /opt/jvm2/jboss-eap-7.1/bin/
./standalone.sh > /opt/jvm2/jboss-eap-7.1/logs/standalone.log &
